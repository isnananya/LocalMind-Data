# 星夜 · LocalMind 界面主题

紫蓝色流星夜城壁纸 + 磨砂玻璃组件。
壁纸来源：Wall-E-Desk（MIT）。
