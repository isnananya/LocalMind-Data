# 月栖 · LocalMind 界面主题

月下湖谷壁纸 + 冷青色调磨砂玻璃。
壁纸来源：Wall-E-Desk（MIT）。
