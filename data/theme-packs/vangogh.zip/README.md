# 星月夜 · 梵高 · 主题设计说明

梵高《星月夜》原作：油画纸纹气泡、缓慢旋转星云与星光、鎏金强调色，四类卡片各自独立样式，附三档字体与三页专属背景。

> 协议：`schemaVersion: 2`。需要支持 v2 段的 App 版本；旧版 App 会忽略 v2 字段，
> 但 `tokens` / `darkTokens` 里的 78 项全局令牌仍然完整生效，不会报错。

## 设计取向

- 主色：星黄 #C2912C（浅）/ #F2C14E（深），普鲁士蓝底 #0A1B33。
- 气泡：纸张 paper 材质 + note 便签轮廓，衬线字体与鎏金描边呼应画框。
- 动效：缓慢旋转星云（nebula）+ 星光装饰闪烁、卡片光泽、按钮缩放反馈。

## 组件级独立样式

四类卡片各有一份令牌覆盖，互不串样式：

| 卡片 | 材质 | 圆角 | 投影 | 背景 |
| --- | --- | --- | --- | --- |
| chatCard | gradient | 10dp | 2 | `#E6142C4B` |
| modelCard | flat | 4dp | 0 | `#E60A1B33` |
| settingCard | neu | 14dp | 3 | `#D91B3552` |
| profileCard | gradient | 20dp | 6 | `#CC3A2D18` |

## 页面专属背景

未声明的页面回退全局壁纸 `vg_wall.jpg`。

| 页面 | 壁纸 | 暗化 | 模糊 |
| --- | --- | --- | --- |
| chat | `vg_page_chat.jpg` | 0.32 | 0dp |
| models | `vg_page_models.jpg` | 0.48 | 14dp |
| me | `vg_page_me.jpg` | 0.30 | 6dp |

## 装饰素材（透明 PNG）

| 文件 | 锚点 | 不透明度 | 运动 |
| --- | --- | --- | --- |
| `vg_decor_stars.png` | top | 0.85 | twinkle |
| `vg_decor_brush.png` | center | 0.38 | none |
| `vg_decor_bokeh.png` | bottom | 0.52 | drift |
| `vg_decor_nebula.png` | center | 0.46 | rotate |

## 动态效果

- `motion.bgAnim = nebula`
- `motion.cardSheen = true`
- `motion.pressFeedback = scale`

## 字体资源（包内携带，三档独立）

- 标题：Ma Shan Zheng 马善政毛笔楷书（SIL OFL 1.1）
- 正文：Noto Serif SC 思源宋体（SIL OFL 1.1）
- 消息：Long Cang 龙藏体（SIL OFL 1.1）

字体经子集化（GB2312 高频字 + 界面符号）后打进 `assets/fonts/`，
分别由 `fonts.title` / `fonts.body` / `fonts.message` 指定。

## 视觉素材

- 原作：**Vincent van Gogh《The Starry Night》（1889）**，作者 1890 年逝世，
  作品属**公有领域**。图像取自 Wikimedia Commons 的公开镜像
  （GitHub: titu1994/Neural-Style-Transfer 与 leongatys/PytorchNeuralStyleTransfer），
  做了竖屏延展、油画颗粒与星点叠加。
- 同系列参考：《Starry Night Over the Rhône》(1888)、《Café Terrace at Night》(1888)。
- 装饰（星芒 / 油画笔触 / 光斑 / 旋转星云）、标签栏图标、商店预览：本项目程序化生成。

## 文件结构

```
plugin.json / ui.json / README.md
assets/vg_wall.jpg                 全局壁纸
assets/pages/vg_page_*.jpg         三页专属背景
assets/fonts/vg_font_*.ttf         三档字体
assets/decor/vg_decor_*.png        透明装饰
assets/icons/vg_icon_*.png         标签栏图标
assets/preview.png                  商店预览
```

所有资源文件名带 `vg_` 前缀：App 解压 `assets/` 时**只按 basename 落盘**，
同名文件会互相覆盖，前缀能保证不会撞车。
