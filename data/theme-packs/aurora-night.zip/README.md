# 极光夜航 · LocalMind 界面主题

暗色极光风格，内置一张星空极光壁纸。

## 装法

**我的 → 插件 → 右上角 +**，选 `极光夜航主题插件.zip`。装完在插件页启用。

## 特色

- **包内壁纸 + 轻微虚化**：`wallpaperBlur` 设为 `2`，星空有一点景深，
  前景文字更清楚。设 `0` 就是锐利星空。
- **拟物卡片**：`cardStyle` 设为 `neu`，卡片带内阴影与厚度。
- **霓虹青强调色**：`accent` 用 `#5EEAD4`，在深底上很跳。

## 令牌速查

| 令牌 | 值 | 说明 |
| --- | --- | --- |
| `accent` | `#5EEAD4` | 强调色（霓虹青） |
| `cardStyle` | `neu` | 拟物卡片 |
| `cardElevation` | `4` | 卡片厚度 |
| `bubbleStyle` | `rounded` | 圆角气泡 |
| `avatarShape` | `rounded` | 圆角头像 |
| `bgStyle` | `wallpaper` | 用包内壁纸 |
| `wallpaperBlur` | `2` | 壁纸模糊（dp） |
| `wallpaperDim` | `0.45` | 壁纸压暗 |

## 授权

MIT。
