# 猫羽雫 · 月猫夜话 · 主题设计说明

猫羽雫重制版：夜蓝月色壁纸、液态玻璃气泡、星光动效，四类卡片各自独立样式，附三档字体与三页专属背景。

> 协议：`schemaVersion: 2`。需要支持 v2 段的 App 版本；旧版 App 会忽略 v2 字段，
> 但 `tokens` / `darkTokens` 里的 78 项全局令牌仍然完整生效，不会报错。

## 设计取向

- 主色：雫蓝 #3D9FE0（浅）/ #7FD4FF（深），夜蓝底 #0B1626。
- 气泡：磨砂 frost + 26dp 圆角 + 柔和光泽，悬浮胶囊液态玻璃底栏。
- 动效：背景星光闪烁（starlight）、卡片光泽扫过、按钮辉光反馈。

## 组件级独立样式

四类卡片各有一份令牌覆盖，互不串样式：

| 卡片 | 材质 | 圆角 | 投影 | 背景 |
| --- | --- | --- | --- | --- |
| chatCard | glass | 26dp | 3 | `#66182F4A` |
| modelCard | flat | 12dp | 0 | `#E60C1C30` |
| settingCard | neu | 18dp | 2 | `#D91A2F46` |
| profileCard | gradient | 30dp | 6 | `#CC27496E` |

## 页面专属背景

未声明的页面回退全局壁纸 `nk_wall.jpg`。

| 页面 | 壁纸 | 暗化 | 模糊 |
| --- | --- | --- | --- |
| chat | `nk_page_chat.jpg` | 0.30 | 0dp |
| models | `nk_page_models.jpg` | 0.42 | 10dp |
| me | `nk_page_me.jpg` | 0.24 | 4dp |

## 装饰素材（透明 PNG）

| 文件 | 锚点 | 不透明度 | 运动 |
| --- | --- | --- | --- |
| `nk_decor_stars.png` | top | 0.82 | twinkle |
| `nk_decor_bokeh.png` | bottom | 0.65 | drift |
| `nk_decor_paws.png` | bottom | 0.42 | none |
| `nk_decor_halo.png` | center | 0.55 | none |

## 动态效果

- `motion.bgAnim = starlight`
- `motion.cardSheen = true`
- `motion.pressFeedback = glow`

## 字体资源（包内携带，三档独立）

- 标题：ZCOOL KuaiLe 站酷快乐体（SIL OFL 1.1）
- 正文：Noto Sans SC 思源黑体（SIL OFL 1.1）
- 消息：ZCOOL XiaoWei 站酷小薇体（SIL OFL 1.1）

字体经子集化（GB2312 高频字 + 界面符号）后打进 `assets/fonts/`，
分别由 `fonts.title` / `fonts.body` / `fonts.message` 指定。

## 视觉素材

- 角色插画：**猫羽雫（ねこは しずく）**，Pixiv 画师 **甘城なつき** 的原创角色。
  本次素材取自公开图库镜像（Safebooru，标签 `nekoha_shizuku`，仅 general 评级），
  经夜色分级、竖屏延展与柔光处理后使用。**角色著作权归原作者所有**，
  本主题包仅作个人使用/学习展示，若公开分发请另行取得授权。
- 装饰（星星 / 光斑 / 猫爪 / 光晕）、标签栏图标、商店预览：本项目程序化生成。

## 文件结构

```
plugin.json / ui.json / README.md
assets/nk_wall.jpg                 全局壁纸
assets/pages/nk_page_*.jpg         三页专属背景
assets/fonts/nk_font_*.ttf         三档字体
assets/decor/nk_decor_*.png        透明装饰
assets/icons/nk_icon_*.png         标签栏图标
assets/preview.png                  商店预览
```

所有资源文件名带 `nk_` 前缀：App 解压 `assets/` 时**只按 basename 落盘**，
同名文件会互相覆盖，前缀能保证不会撞车。
