# 猫羽雫 · LocalMind 界面主题

暗色二次元主题，内置一张猫耳少女夜窗壁纸。

- **磨砂气泡**：AI 气泡是 18% 白 + 白色 0.5dp 描边，壁纸会从气泡里透出来；
- **悬浮胶囊底栏**：`tabBarWidth=compact` + `tabStyle=glass`；
- **玻璃卡片**：`cardStyle=glass` + 大圆角 26；
- 想看清壁纸：把 `wallpaperDim` 调到 0.2。
