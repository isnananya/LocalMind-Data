# 彗星 · LocalMind 界面主题

低饱和暗蓝夜城壁纸，适合深夜使用。
壁纸来源：Wall-E-Desk（MIT）。
