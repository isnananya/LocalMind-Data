# 晴空 · LocalMind 界面主题

蓝天白云壁纸 + 浅色磨砂玻璃。
壁纸来源：Wall-E-Desk（MIT）。
