# QQ经典蓝 · LocalMind 界面主题

复刻 QQ 经典版（2010 年代）的视觉语言：蓝白配色、直角矩形、方形头像、
底部下划线式标签栏。

## 装法

**我的 → 插件 → 右上角 +**，选 `QQ经典蓝主题插件.zip`。装完在插件页启用。

## 特色

- **直角矩形**：`cardCorner` / `controlCorner` 都调到 `4`，复刻老 QQ 的方块控件。
- **纯色底栏**：`tabStyle` 为 `plain`、`tabBarShape` 为 `square`、
  `tabBarIndicator` 为 `underline` —— 标签栏不再是胶囊，是一根下划线。
- **方形头像**：`avatarShape` 设为 `square`。
- **直角气泡**：`bubbleStyle` 设为 `square`。
- **无阴影卡片**：`cardStyle` 为 `flat`、`cardElevation` 为 `0`。

## 令牌速查

| 令牌 | 值 | 说明 |
| --- | --- | --- |
| `accent` | `#12B7F5` | QQ 蓝 |
| `cardCorner` | `4` | 直角卡片 |
| `tabStyle` | `plain` | 纯色标签栏 |
| `tabBarIndicator` | `underline` | 下划线选中指示 |
| `bubbleStyle` | `square` | 直角气泡 |
| `avatarShape` | `square` | 方形头像 |
| `bgStyle` | `flat` | 纯色背景（无壁纸） |

## 授权

MIT。
